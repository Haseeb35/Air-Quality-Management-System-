# import pandas as pd
# import numpy as np
# from sklearn.model_selection import train_test_split
# from sklearn.preprocessing import StandardScaler
# from sklearn.svm import SVC
# from sklearn.neighbors import KNeighborsClassifier
# from sklearn.metrics import accuracy_score, classification_report
# import joblib
# import os

# # ==========================================
# # 1. LOAD EXISTING DATASET
# # ==========================================
# file_name = 'air_quality_1000_records.csv'

# if os.path.exists(file_name):
#     print(f"Reading data from {file_name}...")
#     df = pd.read_csv(file_name)
# else:
#     print(f"Error: {file_name} nahi mili! Pehle dataset wali file banayein.")
#     exit()

# # ==========================================
# # 2. DATA PREPROCESSING & SCALING
# # ==========================================
# # Features select karein (Timestamp ko nikal kar baaki sab)
# X = df[['Tempature_Sensor', 'Humidity_Sensor', 'MQ135', 'C02_Levels']]
# y = df['Air_Quality_Index']

# # Split data (80% Training, 20% Testing)
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # Scaling (Zaroori: Kyunki SVM/KNN distance base algorithms hain)
# scaler = StandardScaler()
# X_train_scaled = scaler.fit_transform(X_train)
# X_test_scaled = scaler.transform(X_test)

# # ==========================================
# # 3. SVM MODEL TRAINING
# # ==========================================
# print("\n--- Training SVM Model ---")
# svm_model = SVC(kernel='linear', C=1.0, random_state=42)
# svm_model.fit(X_train_scaled, y_train)

# svm_pred = svm_model.predict(X_test_scaled)
# print(f"SVM Accuracy: {accuracy_score(y_test, svm_pred) * 100:.2f}%")

# # ==========================================
# # 4. KNN MODEL TRAINING
# # ==========================================
# print("\n--- Training KNN Model ---")
# knn_model = KNeighborsClassifier(n_neighbors=5)
# knn_model.fit(X_train_scaled, y_train)

# knn_pred = knn_model.predict(X_test_scaled)
# print(f"KNN Accuracy: {accuracy_score(y_test, knn_pred) * 100:.2f}%")
# print("\nKNN Classification Report:\n", classification_report(y_test, knn_pred))

# # ==========================================
# # 5. MODELS & SCALER SAVE KAREIN
# # ==========================================
# joblib.dump(svm_model, 'svm_air_quality.pkl')
# joblib.dump(knn_model, 'knn_air_quality.pkl')
# joblib.dump(scaler, 'data_scaler.pkl')

# print("\nSuccess: Models aur Scaler save ho gaye hain!")

# # ==========================================
# # 6. PREDICTION FUNCTION
# # ==========================================
# def predict_quality(temp, hum, mq, co2):
#     # Saved models load karein
#     sc = joblib.load('data_scaler.pkl')
#     model = joblib.load('svm_air_quality.pkl') # Aap knn_air_quality.pkl bhi use kar sakte hain
    
#     # Input ko DataFrame mein convert karein warning se bachne ke liye
#     cols = ['Tempature_Sensor', 'Humidity_Sensor', 'MQ135', 'C02_Levels']
#     input_df = pd.DataFrame([[temp, hum, mq, co2]], columns=cols)
    
#     # Scale aur Predict
#     input_scaled = sc.transform(input_df)
#     res = model.predict(input_scaled)
    
#     labels = {0: "Safe (Good)", 1: "Warning (Moderate)", 2: "Hazardous (Poor)"}
#     return labels[res[0]]

# # Test Prediction
# print("\nTest Prediction:")
# print(f"Result: {predict_quality(28.5, 45, 600, 800)}")

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib
import os

# ==========================================
# 1. LOAD EXISTING DATASET
# ==========================================
file_name = "air_quality_1000_records.csv"

if os.path.exists(file_name):
    print(f"Reading data from {file_name}...")
    df = pd.read_csv(file_name)
else:
    print(f"Error: {file_name} nahi mili! Pehle dataset wali file banayein.")
    exit()

# ==========================================
# 2. CHECK REQUIRED COLUMNS
# ==========================================
required_cols = [
    "Tempature_Sensor",
    "Humidity_Sensor",
    "MQ135",
    "C02_Levels",
    "Air_Quality_Index",
]

for col in required_cols:
    if col not in df.columns:
        print(f"Error: Dataset me '{col}' column missing hai.")
        exit()

print("\nDataset label distribution:")
print(df["Air_Quality_Index"].value_counts())

# ==========================================
# 3. FEATURES & TARGET
# ==========================================
X = df[["Tempature_Sensor", "Humidity_Sensor", "MQ135", "C02_Levels"]]
y = df["Air_Quality_Index"]

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# Scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ==========================================
# 4. SVM MODEL TRAINING
# ==========================================
print("\n--- Training SVM Model ---")

svm_model = SVC(kernel="linear", C=1.0, random_state=42)
svm_model.fit(X_train_scaled, y_train)

svm_pred = svm_model.predict(X_test_scaled)

print(f"SVM Accuracy: {accuracy_score(y_test, svm_pred) * 100:.2f}%")
print("\nSVM Classification Report:\n")
print(classification_report(y_test, svm_pred))

# ==========================================
# 5. KNN MODEL TRAINING
# ==========================================
print("\n--- Training KNN Model ---")

knn_model = KNeighborsClassifier(n_neighbors=5)
knn_model.fit(X_train_scaled, y_train)

knn_pred = knn_model.predict(X_test_scaled)

print(f"KNN Accuracy: {accuracy_score(y_test, knn_pred) * 100:.2f}%")
print("\nKNN Classification Report:\n")
print(classification_report(y_test, knn_pred))

# ==========================================
# 6. SAVE MODELS & SCALER
# ==========================================
joblib.dump(svm_model, "svm_air_quality.pkl")
joblib.dump(knn_model, "knn_air_quality.pkl")
joblib.dump(scaler, "data_scaler.pkl")

print("\nSuccess: Models aur Scaler save ho gaye hain!")

# ==========================================
# 7. PREDICTION FUNCTION
# ==========================================
def predict_quality(temp, hum, mq135, co2):
    sc = joblib.load("data_scaler.pkl")
    svm = joblib.load("svm_air_quality.pkl")
    knn = joblib.load("knn_air_quality.pkl")

    cols = ["Tempature_Sensor", "Humidity_Sensor", "MQ135", "C02_Levels"]

    input_df = pd.DataFrame(
        [[temp, hum, mq135, co2]],
        columns=cols
    )

    input_scaled = sc.transform(input_df)

    svm_res = int(svm.predict(input_scaled)[0])
    knn_res = int(knn.predict(input_scaled)[0])

    labels = {
        0: "Safe (Good)",
        1: "Warning (Moderate)",
        2: "Hazardous (Poor)",
    }

    return labels[svm_res], labels[knn_res]

# ==========================================
# 8. TEST PREDICTIONS
# ==========================================
print("\nTest Prediction 1:")
print("Temp = 27, Humidity = 65, MQ135 = 434, CO2 = 337")
svm_result, knn_result = predict_quality(27, 65, 434, 337)
print("SVM:", svm_result)
print("KNN:", knn_result)

print("\nTest Prediction 2:")
print("Temp = 27, Humidity = 65, MQ135 = 500, CO2 = 650")
svm_result, knn_result = predict_quality(27, 65, 500, 650)
print("SVM:", svm_result)
print("KNN:", knn_result)

print("\nTest Prediction 3:")
print("Temp = 27, Humidity = 65, MQ135 = 300, CO2 = 850")
svm_result, knn_result = predict_quality(27, 65, 300, 850)
print("SVM:", svm_result)
print("KNN:", knn_result)

print("\nTest Prediction 4:")
print("Temp = 37, Humidity = 65, MQ135 = 300, CO2 = 337")
svm_result, knn_result = predict_quality(37, 65, 300, 337)
print("SVM:", svm_result)
print("KNN:", knn_result)