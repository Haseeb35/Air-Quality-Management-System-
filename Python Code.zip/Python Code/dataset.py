# import pandas as pd
# import numpy as np
# from datetime import datetime, timedelta

# # 1000 records generate karne ke liye
# n_records = 1000
# start_time = datetime.now()

# # Data Ranges setup (Based on your Firebase screenshot)
# data = {
#     'Timestamp': [(start_time - timedelta(minutes=10*i)).strftime('%Y-%m-%d %H:%M:%S') for i in range(n_records)],
#     'Tempature_Sensor': np.round(np.random.uniform(14.0, 32.0, n_records), 1),
#     'Humidity_Sensor': np.random.randint(30, 75, n_records),
#     'MQ135': np.random.randint(150, 950, n_records),
#     'C02_Levels': np.random.randint(180, 1100, n_records),
# }

# df = pd.DataFrame(data)

# # Target Logic (Prediction ke liye categories)
# def classify_air_quality(row):
#     # MQ135 aur CO2 levels par base classification
#     score = (row['MQ135'] * 0.6) + (row['C02_Levels'] * 0.4)
#     if score < 400:
#         return 0  # Good (Safe)
#     elif score < 700:
#         return 1  # Moderate (Warning)
#     else:
#         return 2  # Poor (Hazardous)

# df['Air_Quality_Index'] = df.apply(classify_air_quality, axis=1)

# # CSV File Save karein
# df.to_csv('air_quality_1000_records.csv', index=False)
# print("1000 records ka dataset 'air_quality_1000_records.csv' tyar hai!")

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# 1000 records generate karne ke liye
n_records = 1000
start_time = datetime.now()

# Data Ranges setup
data = {
    "Timestamp": [
        (start_time - timedelta(minutes=10 * i)).strftime("%Y-%m-%d %H:%M:%S")
        for i in range(n_records)
    ],

    # Temperature range thori high rakhi hai taake temp > 35 wali warning bhi model seekh sake
    "Tempature_Sensor": np.round(np.random.uniform(14.0, 42.0, n_records), 1),

    "Humidity_Sensor": np.random.randint(30, 75, n_records),

    # Raw sensor ranges
    "MQ135": np.random.randint(150, 950, n_records),
    "C02_Levels": np.random.randint(180, 1100, n_records),
}

df = pd.DataFrame(data)

# ==========================================
# Target Logic - Same as Frontend Screens
# ==========================================
def classify_air_quality(row):
    temp = row["Tempature_Sensor"]
    mq135 = row["MQ135"]
    co2 = row["C02_Levels"]

    if co2 >= 800 or mq135 >= 800:
        return 2  # Poor / Hazardous

    elif co2 >= 600 or mq135 >= 600:
        return 1  # Moderate / Warning

    else:
        return 0  # Good / Safe


df["Air_Quality_Index"] = df.apply(classify_air_quality, axis=1)

# Check labels count
print("Label Distribution:")
print(df["Air_Quality_Index"].value_counts())

# CSV File Save karein
df.to_csv("air_quality_1000_records.csv", index=False)

print("1000 records ka updated dataset 'air_quality_1000_records.csv' tyar hai!")