# from flask import Flask, request, jsonify
# from flask_cors import CORS
# import joblib
# import pandas as pd
# import os

# app = Flask(__name__)
# CORS(app)

# # ==========================================
# # MODELS LOAD
# # ==========================================
# base_dir = os.path.dirname(os.path.abspath(__file__))

# scaler = joblib.load(os.path.join(base_dir, "data_scaler.pkl"))
# svm_model = joblib.load(os.path.join(base_dir, "svm_air_quality.pkl"))
# knn_model = joblib.load(os.path.join(base_dir, "knn_air_quality.pkl"))

# labels = {
#     0: "Safe (Good)",
#     1: "Warning (Moderate)",
#     2: "Hazardous (Poor)"
# }

# # ==========================================
# # SAME THRESHOLD AS FRONTEND
# # ==========================================
# def rule_based_quality(temp, hum, mq135, co2):
#     if co2 >= 800 or mq135 >= 800:
#         return "Hazardous (Poor)"

#     if co2 >= 600 or mq135 >= 600 or temp > 35:
#         return "Warning (Moderate)"

#     return "Safe (Good)"


# @app.route("/predict", methods=["POST"])
# def predict():
#     try:
#         data = request.json

#         if not data:
#             return jsonify({
#                 "status": "error",
#                 "message": "No JSON data received"
#             })

#         temp = float(data.get("temp", 0))
#         hum = float(data.get("humidity", 0))
#         mq135 = float(data.get("mq135", 0))
#         co2 = float(data.get("co2", 0))

#         # ==========================================
#         # MODEL INPUT
#         # Column names must match training exactly
#         # C02_Levels = C zero 2, not CO2
#         # ==========================================
#         cols = ["Tempature_Sensor", "Humidity_Sensor", "MQ135", "C02_Levels"]

#         df = pd.DataFrame(
#             [[temp, hum, mq135, co2]],
#             columns=cols
#         )

#         scaled = scaler.transform(df)

#         # ML predictions
#         svm_res = int(svm_model.predict(scaled)[0])
#         knn_res = int(knn_model.predict(scaled)[0])

#         svm_label_raw = labels[svm_res]
#         knn_label_raw = labels[knn_res]

#         # ==========================================
#         # FINAL SAFETY OVERRIDE
#         # Ye frontend ke thresholds ke sath 100% same rakhega
#         # ==========================================
#         final_label = rule_based_quality(temp, hum, mq135, co2)

#         return jsonify({
#             "status": "success",

#             # Frontend in fields ko show karta hai
#             "svm": final_label,
#             "knn": final_label,

#             # Debug ke liye raw ML output bhi bhej rahe hain
#             "svm_raw": svm_label_raw,
#             "knn_raw": knn_label_raw,

#             "received": {
#                 "temp": temp,
#                 "humidity": hum,
#                 "mq135": mq135,
#                 "co2": co2
#             }
#         })

#     except Exception as e:
#         print(f"Prediction Error: {e}")
#         return jsonify({
#             "status": "error",
#             "message": str(e)
#         })


# if __name__ == "__main__":
#     app.run(port=5000, debug=True)

from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

def final_air_quality(co2, mq135):
    # Final thresholds:
    # Safe: below 600
    # Warning: 600 to 799
    # Hazardous: 800+

    if co2 >= 800 or mq135 >= 800:
        return "Hazardous (Poor)"

    if co2 >= 600 or mq135 >= 600:
        return "Warning (Moderate)"

    return "Safe (Good)"


@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.json

        temp = float(data.get("temp", 0))
        humidity = float(data.get("humidity", 0))
        co2 = float(data.get("co2", 0))
        mq135 = float(data.get("mq135", 0))

        print("RECEIVED VALUES:")
        print("Temp:", temp)
        print("Humidity:", humidity)
        print("CO2:", co2)
        print("MQ135:", mq135)

        final_label = final_air_quality(co2, mq135)

        print("FINAL RESULT:", final_label)

        return jsonify({
            "status": "success",
            "svm": final_label,
            "knn": final_label,
            "received": {
                "temp": temp,
                "humidity": humidity,
                "co2": co2,
                "mq135": mq135
            }
        })

    except Exception as e:
        print("Prediction Error:", e)
        return jsonify({
            "status": "error",
            "message": str(e)
        })


@app.route("/", methods=["GET"])
def home():
    return "Flask prediction server is running"


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)