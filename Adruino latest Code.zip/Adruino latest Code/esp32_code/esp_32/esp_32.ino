#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>

const char* ssid = "Mr Tech";
const char* password = "Arham2014";

// Apna Firebase Realtime Database URL yahan lagao
String firebaseBaseUrl = "https://air-quality-system-1a337-default-rtdb.firebaseio.com/";

// Device path
String devicePath = "/air_quality/device1";

HardwareSerial ArduinoSerial(2);

// ESP32 RX2 = GPIO16
// ESP32 TX2 = GPIO17

void setup() {
  Serial.begin(115200);

  ArduinoSerial.begin(9600, SERIAL_8N1, 16, 17);

  WiFi.begin(ssid, password);

  Serial.print("Connecting WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi Connected");
}

void updateCurrentData(float temp, float hum, int mq7, int mq135, float lat, float lon, String lastRx) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi not connected");
    return;
  }

  WiFiClientSecure client;
  client.setInsecure();

  HTTPClient http;

  String url = firebaseBaseUrl + devicePath + ".json";

  http.begin(client, url);
  http.addHeader("Content-Type", "application/json");

  String json = "{";
  json += "\"CO2_Levels\":" + String(mq7) + ",";
  json += "\"Humidity_Sensor\":" + String(hum, 0) + ",";
  json += "\"MQ135\":" + String(mq135) + ",";
  json += "\"Tempature_Sensor\":" + String(temp, 0) + ",";
  json += "\"last_rx\":\"" + lastRx + "\",";
  json += "\"lat\":" + String(lat, 6) + ",";
  json += "\"lon\":" + String(lon, 6);
  json += "}";

  int httpCode = http.PATCH(json);

  Serial.print("Current Data Response: ");
  Serial.println(httpCode);

  http.end();
}

void addHistoryData(float temp, float hum, int mq7, int mq135, float lat, float lon) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi not connected");
    return;
  }

  WiFiClientSecure client;
  client.setInsecure();

  HTTPClient http;

  String url = firebaseBaseUrl + devicePath + "/history.json";

  http.begin(client, url);
  http.addHeader("Content-Type", "application/json");

  String json = "{";
  json += "\"CO2_Levels\":" + String(mq7) + ",";
  json += "\"Humidity_Sensor\":" + String(hum, 0) + ",";
  json += "\"MQ135\":" + String(mq135) + ",";
  json += "\"Tempature_Sensor\":" + String(temp, 0) + ",";
  json += "\"lat\":" + String(lat, 6) + ",";
  json += "\"lon\":" + String(lon, 6);
  json += "}";

  int httpCode = http.POST(json);

  Serial.print("History Response: ");
  Serial.println(httpCode);

  http.end();
}

void handleArduinoData(String data) {
  data.trim();

  if (!data.startsWith("DATA,")) {
    Serial.println("Invalid data");
    return;
  }

  String lastRx = data;
  lastRx.replace("DATA,", "");

  float temp, hum, lat, lon;
  int mq7, mq135;

  int result = sscanf(
    data.c_str(),
    "DATA,%f,%f,%d,%d,%f,%f",
    &temp,
    &hum,
    &mq7,
    &mq135,
    &lat,
    &lon
  );

  if (result == 6) {
    Serial.println("Valid data received");

    updateCurrentData(temp, hum, mq7, mq135, lat, lon, lastRx);
    addHistoryData(temp, hum, mq7, mq135, lat, lon);
  } else {
    Serial.println("Data format error");
    Serial.println(data);
  }
}

void loop() {
  if (ArduinoSerial.available()) {
    String data = ArduinoSerial.readStringUntil('\n');

    Serial.print("Received: ");
    Serial.println(data);

    handleArduinoData(data);
  }
}