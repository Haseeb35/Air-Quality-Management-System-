// #include <Wire.h>
// #include <LiquidCrystal_I2C.h>
// #include <DHT.h>
// #include <SoftwareSerial.h>
// #include <TinyGPSPlus.h>

// LiquidCrystal_I2C lcd(0x27, 16, 2);

// #define DHTPIN A0
// #define DHTTYPE DHT11
// #define MQ7PIN A1
// #define MQ135PIN A2

// DHT dht(DHTPIN, DHTTYPE);

// // GPS: Arduino RX, TX
// SoftwareSerial gpsSerial(4, 3);

// // ESP32: Arduino RX, TX
// // Arduino D9 TX will send data to ESP32 GPIO16 RX
// SoftwareSerial espSerial(8, 9);

// TinyGPSPlus gps;

// float temp = 0;
// float hum = 0;
// int mq7Value = 0;
// int mq135Value = 0;
// float latitude = 0;
// float longitude = 0;

// void printCenter(String text, int row) {
//   int startPosition = (16 - text.length()) / 2;
//   lcd.setCursor(startPosition, row);
//   lcd.print(text);
// }

// void readDHT11() {
//   temp = dht.readTemperature();
//   hum = dht.readHumidity();

//   if (isnan(temp) || isnan(hum)) {
//     delay(1000);

//     temp = dht.readTemperature();
//     hum = dht.readHumidity();
//   }

//   if (isnan(temp) || isnan(hum)) {
//     Serial.println("DHT11 Error!");
//     temp = 0;
//     hum = 0;

//     lcd.clear();
//     lcd.setCursor(0, 0);
//     lcd.print("DHT11 Error");
//     lcd.setCursor(0, 1);
//     lcd.print("Check Sensor");
//     return;
//   }

//   Serial.print("Temp: ");
//   Serial.print(temp);
//   Serial.println(" C");

//   Serial.print("Humidity: ");
//   Serial.print(hum);
//   Serial.println(" %");
// }

// void readMQ7() {
//   mq7Value = analogRead(MQ7PIN);

//   Serial.print("MQ7 Value: ");
//   Serial.println(mq7Value);
// }

// void readMQ135() {
//   mq135Value = analogRead(MQ135PIN);

//   Serial.print("MQ135 Value: ");
//   Serial.println(mq135Value);
// }

// void readGPS() {
//   gpsSerial.listen();

//   unsigned long startTime = millis();

//   while (millis() - startTime < 2000) {
//     while (gpsSerial.available()) {
//       gps.encode(gpsSerial.read());
//     }
//   }

//   if (gps.location.isValid()) {
//     latitude = gps.location.lat();
//     longitude = gps.location.lng();

//     Serial.print("Latitude: ");
//     Serial.println(latitude, 6);

//     Serial.print("Longitude: ");
//     Serial.println(longitude, 6);
//   } else {
//     Serial.println("GPS searching...");
//   }
// }

// void showOnLCD() {
//   lcd.clear();
//   lcd.setCursor(0, 0);
//   lcd.print("T:");
//   lcd.print(temp);
//   lcd.print(" H:");
//   lcd.print(hum);

//   lcd.setCursor(0, 1);
//   lcd.print("M7:");
//   lcd.print(mq7Value);
//   lcd.print(" M135:");
//   lcd.print(mq135Value);
// }

// void sendDataToESP32() {
//   espSerial.print("DATA,");
//   espSerial.print(temp);
//   espSerial.print(",");
//   espSerial.print(hum);
//   espSerial.print(",");
//   espSerial.print(mq7Value);
//   espSerial.print(",");
//   espSerial.print(mq135Value);
//   espSerial.print(",");
//   espSerial.print(latitude, 6);
//   espSerial.print(",");
//   espSerial.println(longitude, 6);

//   Serial.println("Data sent to ESP32");
// }

// void setup() {
//   Serial.begin(9600);
//   gpsSerial.begin(9600);
//   espSerial.begin(9600);

//   lcd.init();
//   lcd.backlight();

//   dht.begin();

//   printCenter("Air Quality!", 0);
//   printCenter("System", 1);

//   Serial.println("System Started");

//   delay(1000); 
// }

// void loop() {
//   readGPS();
//   readDHT11();
//   readMQ7();
//   readMQ135();
//   showOnLCD();
//   sendDataToESP32();

//   Serial.println("----------------");

//   delay(8000);
// }

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>
#include <SoftwareSerial.h>
#include <TinyGPSPlus.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

#define DHTPIN A0
#define DHTTYPE DHT11
#define MQ7PIN A1
#define MQ135PIN A2

DHT dht(DHTPIN, DHTTYPE);

// GPS: Arduino RX, TX
SoftwareSerial gpsSerial(4, 3);

// ESP32: Arduino RX, TX
// Arduino D9 TX will send data to ESP32 GPIO16 RX
SoftwareSerial espSerial(8, 9);

TinyGPSPlus gps;

float temp = 0;
float hum = 0;
int mq7Value = 0;
int mq135Value = 0;
float latitude = 0;
float longitude = 0;

bool gpsValid = false;
int lcdPage = 0;

void printCenter(String text, int row) {
  int startPosition = (16 - text.length()) / 2;
  if (startPosition < 0) startPosition = 0;
  lcd.setCursor(startPosition, row);
  lcd.print(text);
}

void readDHT11() {
  temp = dht.readTemperature();
  hum = dht.readHumidity();

  if (isnan(temp) || isnan(hum)) {
    delay(1000);
    temp = dht.readTemperature();
    hum = dht.readHumidity();
  }

  if (isnan(temp) || isnan(hum)) {
    Serial.println("DHT11 Error!");
    temp = 0;
    hum = 0;

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("DHT11 Error");
    lcd.setCursor(0, 1);
    lcd.print("Check Sensor");
    return;
  }

  Serial.print("Temp: ");
  Serial.print(temp);
  Serial.println(" C");

  Serial.print("Humidity: ");
  Serial.print(hum);
  Serial.println(" %");
}

void readMQ7() {
  mq7Value = analogRead(MQ7PIN);

  Serial.print("MQ7 Value: ");
  Serial.println(mq7Value);
}

void readMQ135() {
  mq135Value = analogRead(MQ135PIN);

  Serial.print("MQ135 Value: ");
  Serial.println(mq135Value);
}

void readGPS() {
  gpsSerial.listen();

  unsigned long startTime = millis();

  while (millis() - startTime < 2000) {
    while (gpsSerial.available()) {
      gps.encode(gpsSerial.read());
    }
  }

  if (gps.location.isValid()) {
    latitude = gps.location.lat();
    longitude = gps.location.lng();
    gpsValid = true;

    Serial.print("Latitude: ");
    Serial.println(latitude, 6);

    Serial.print("Longitude: ");
    Serial.println(longitude, 6);
  } else {
    gpsValid = false;
    Serial.println("GPS searching...");
  }
}

void showSensorLCD() {
  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print("T:");
  lcd.print(temp, 1);
  lcd.print("C H:");
  lcd.print(hum, 0);
  lcd.print("%");

  lcd.setCursor(0, 1);
  lcd.print("M7:");
  lcd.print(mq7Value);
  lcd.print(" MQ:");
  lcd.print(mq135Value);
}

void showGPSLCD() {
  lcd.clear();

  if (gpsValid) {
    lcd.setCursor(0, 0);
    lcd.print("Lat:");
    lcd.print(latitude, 6);

    lcd.setCursor(0, 1);
    lcd.print("Lon:");
    lcd.print(longitude, 6);
  } else {
    lcd.setCursor(0, 0);
    lcd.print("GPS Searching");
    lcd.setCursor(0, 1);
    lcd.print("Wait Signal...");
  }
}

void showOnLCD() {
  if (lcdPage == 0) {
    showSensorLCD();
    lcdPage = 1;
  } else {
    showGPSLCD();
    lcdPage = 0;
  }
}

void sendDataToESP32() {
  espSerial.print("DATA,");
  espSerial.print(temp);
  espSerial.print(",");
  espSerial.print(hum);
  espSerial.print(",");
  espSerial.print(mq7Value);
  espSerial.print(",");
  espSerial.print(mq135Value);
  espSerial.print(",");
  espSerial.print(latitude, 6);
  espSerial.print(",");
  espSerial.println(longitude, 6);

  Serial.println("Data sent to ESP32");
}

void setup() {
  Serial.begin(9600);
  gpsSerial.begin(9600);
  espSerial.begin(9600);

  lcd.init();
  lcd.backlight();

  dht.begin();

  printCenter("Air Quality!", 0);
  printCenter("System", 1);

  Serial.println("System Started");

  delay(1500);
}

void loop() {
  readGPS();
  readDHT11();
  readMQ7();
  readMQ135();

  showOnLCD();

  sendDataToESP32();

  Serial.println("----------------");

  delay(8000);
}